import React from 'react';
import { Grid, Typography, Box } from '@mui/material';
import images from '../ImageCom/logo.png'
import './Footer.css';
function Footer() {
  return (
    <Box className="kf-footer" sx={{ padding: '70px 0 0 0'}}>
      <Grid container spacing={3} className="container" style={{background: 'black'}}>
        <Grid item xs={12} sm={6} md={3}>
          <Box className="kf-logo element-anim-1 scroll-animate animate__active animate__animated" data-animate="active" sx={{ visibility: 'visible' }}>
            <a href="index.html">
            <img src={images} alt="Footer Logo" style={{ maxWidth: '80%', width: 'auto', maxHeight: '100px' }} />
            </a>
          </Box>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Box className="kf-f-hours element-anim-1 scroll-animate animate__active animate__animated" data-animate="active" sx={{ visibility: 'visible' }}>
            <Typography variant="h5">Business hours</Typography>
            <ul>
              <li>
                Monday - Friday
                <em>LUNCH: 11 AM - 3 PM</em>
                <em>DINNER: 5 PM - 10 PM</em>
                Saturday - Sunday: 11 AM - 10 PM
              </li>
            </ul>
          </Box>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Box className="kf-f-contact element-anim-1 scroll-animate animate__active animate__animated" data-animate="active" sx={{ visibility: 'visible' }}>
            <Typography variant="h5">Contact Us</Typography>
            <ul>
              <li>
                <i className="las la-map-marker" style={{fontSize: '40px',
    color: 'red'}}></i>
                <em>Location :</em>
                2215 US-1 SOUTH, North Brunswick Township, NJ 08902
              </li>
              <li>
                <i className="las la-phone" style={{fontSize: '40px',
    color: 'red'}}></i>
                <em>Phone Number :</em>
                (732) 398-9022
              </li>
            </ul>
          </Box>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Box className="kf-f-gallery element-anim-1 scroll-animate animate__active animate__animated" data-animate="active" sx={{ visibility: 'visible' }}>
            <Typography variant="h5">Gallery</Typography>
            <ul>
              <li>
                <a href="images/ga1.jpg" className="kf-image-hover has-popup-image">
                  <img src="../ImageCom/img1.jpg" alt="" />
                </a>
              </li>
              <li>
                <a href="images/ga2.jpg" className="kf-image-hover has-popup-image">
                  <img src="images/ga2.jpg" alt="" />
                </a>
              </li>
              <li>
                <a href="images/ga3.jpg" className="kf-image-hover has-popup-image">
                  <img src="images/ga3.jpg" alt="" />
                </a>
              </li>
              <li>
                <a href="images/ga4.jpg" className="kf-image-hover has-popup-image">
                  <img src="images/ga4.jpg" alt="" />
                </a>
              </li>
              <li>
                <a href="images/ga5.jpg" className="kf-image-hover has-popup-image">
                  <img src="images/ga5.jpg" alt="" />
                </a>
              </li>
              <li>
                <a href="images/ga6.jpg" className="kf-image-hover has-popup-image">
                  <img src="images/ga6.jpg" alt="" />
                </a>
              </li>
            </ul>
          </Box>
        </Grid>
      </Grid>
      <Grid container className="container" style={{background: 'black'}}>
        <Grid item xs={12} className="align-center">
          <Box className="kf-copyright element-anim-1 scroll-animate animate__active animate__animated" data-animate="active" sx={{ visibility: 'visible' }}>
            Copyright © 2024 Guru Palace. All Rights Reserved. | Crafted by{' '}
            <a href="" target="blank">
              ePower POS
            </a>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}

export default Footer;
